//
//  HomeViewModel.swift
//  OnlineGrocery
//
//  Created by Amit Kumar on 5/20/24.
//

import Foundation
import SwiftUI

class HomeViewModel:ObservableObject {
    static var shared: HomeViewModel = HomeViewModel()
    @Published var selectTab: Int = 0
    @Published var txtSearch: String = ""
    
}
