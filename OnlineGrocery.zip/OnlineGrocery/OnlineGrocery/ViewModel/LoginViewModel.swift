//
//  LoginViewModel.swift
//  OnlineGrocery
//
//  Created by Amit Kumar on 5/14/24.
//

import SwiftUI

class LoginViewModel: ObservableObject  {
    static var shared: LoginViewModel = LoginViewModel()
    @Published var txtUsername: String = ""
    @Published var txtEmail: String = ""
    @Published var txtPassWord: String = ""
    @Published var isShowPassword: Bool = false
    @Published var showError = false
    @Published var errorMessage = ""
    @Published var isUserLogin: Bool = false
    @Published var userObj: UserModel = UserModel(dict: [:])
    init() {
        
        if( Utils.UDValueBool(key: Globs.userLogin) ) {
            self.setUserData(uDict: Utils.UDValue(key: Globs.userPayload) as? NSDictionary ?? [:])
        } else {
             // user not login
        }
        #if DEBUG
        txtUsername = ""
        txtEmail = ""
        txtPassWord = ""
        #endif
    }
    //MARK: ServiceCall
    func serviceCallLogin() {
        if (!txtEmail.isValidEmail) {
            self.errorMessage = "Please enter valid email address"
            self.showError = true
            return
        }
        if txtPassWord.isEmpty {
            self.errorMessage = "Please enter valid password"
            self.showError = true
            return
        }
        ServiceCall.post(parameter: ["email": txtEmail, "password": txtPassWord, "device_token":"" ], path: Globs.SV_LOGIN) { responseObj in
            if let response = responseObj as? NSDictionary {
                if response.value(forKey: KKey.status) as? String ?? "" == "1" {
                    print(response)
                    self.setUserData(uDict: response.value(forKey: KKey.payload) as? NSDictionary ?? [:])

                } else {
                    self.errorMessage = response.value(forKey: KKey.message) as? String ?? "Fail"
                    self.showError = true
                }
            }
        } failure: { error in
            self.errorMessage = error?.localizedDescription ?? "Failure"
            self.showError = true

        }

    }
    
    //MARK: ServiceCall
    func serviceCallSignUp() {
        if (txtUsername.isEmpty) {
            self.errorMessage = "Please enter valid user name"
            self.showError = true
            return
        }
        if (!txtEmail.isValidEmail) {
            self.errorMessage = "Please enter valid email address"
            self.showError = true
            return
        }
        if txtPassWord.isEmpty {
            self.errorMessage = "Please enter valid password"
            self.showError = true
            return
        }
        ServiceCall.post(parameter: ["username": txtUsername,"email": txtEmail, "password": txtPassWord, "device_token":"" ], path: Globs.SV_LOGIN) { responseObj in
            if let response = responseObj as? NSDictionary {
                if response.value(forKey: KKey.status) as? String ?? "" == "1" {
                    self.setUserData(uDict: response.value(forKey: KKey.payload) as? NSDictionary ?? [:])
                   
                } else {
                    self.errorMessage = response.value(forKey: KKey.message) as? String ?? "Fail"
                    self.showError = true
                }
            }
        } failure: { error in
            self.errorMessage = error?.localizedDescription ?? "Failure"
            self.showError = true

        }

    }
    func setUserData(uDict: NSDictionary) {
        Utils.UDSET(data:uDict, key: Globs.userPayload)
        Utils.UDSET(data: uDict, key: Globs.userLogin)
        self.userObj = UserModel(dict: uDict)
        self.txtUsername = ""
        self.txtEmail = ""
        self.txtPassWord = ""
        self.isShowPassword = false
    }
}
