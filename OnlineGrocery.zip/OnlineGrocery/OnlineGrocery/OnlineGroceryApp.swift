//
//  OnlineGroceryApp.swift
//  OnlineGrocery
//
//  Created by Amit Kumar on 5/11/24.
//

import SwiftUI

@main
struct OnlineGroceryApp: App {
    @StateObject var loginVM = LoginViewModel.shared
    var body: some Scene {
        WindowGroup {
            NavigationView {
                if loginVM.isUserLogin {
                    MainTabView()
                } else {
                    WelcomeView()
                }
            }
            
        }
    }
}
