//
//  SearchTextFiled.swift
//  OnlineGrocery
//
//  Created by Amit Kumar on 5/21/24.
//

import SwiftUI

struct SearchTextFiled: View {
    @State var placeholder: String = "Placeholder"
    @Binding var txt: String
    var body: some View {
        HStack(spacing: 15) {
            Image("search")
                .resizable()
                .scaledToFit()
                .frame(width: 12, height: 12)
            
            TextField(placeholder,text: $txt)
                .font(.customfont(.regular, fontSize: 17))
                .autocapitalization(.none)
                .disableAutocorrection(true)
                .frame(minWidth: 0, maxWidth:.infinity)
        }
        .frame(height: 30)
        .padding(15)
        .background(Color(hex: "F2F3F2"))
        .cornerRadius(16)
    }
}

struct SearchTextFiled_Previews: PreviewProvider {
    @State static var txt: String = ""
    static var previews: some View {
        SearchTextFiled(placeholder: "Search Store", txt: $txt)
            .padding(15)
    }
}
