//
//  CountryPickerUI.swift
//  OnlineGrocery
//
//  Created by Amit Kumar on 5/11/24.
//

import SwiftUI
import CountryPicker
struct CountryPickerUI: UIViewControllerRepresentable {
    @Binding var country: Country?
    class Coordinator:NSObject, CountryPickerDelegate {
        var parentObj: CountryPickerUI
        init( _parent: CountryPickerUI) {
            self.parentObj = _parent
        }
        func countryPicker(didSelect country: Country) {
            parentObj.country = country
        }
      
    }
    func makeUIViewController(context: Context) -> some CountryPickerViewController {
        let countryPicker = CountryPickerViewController()
        countryPicker.selectedCountry = "IN"
        countryPicker.delegate = context.coordinator
        return countryPicker
    }
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
        
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(_parent: self)
    }
}
