//
//  SectionTitleAll.swift
//  OnlineGrocery
//
//  Created by Amit Kumar on 5/27/24.
//

import SwiftUI

struct SectionTitleAll: View {
    @State var title: String = "Title"
    @State var titleAll: String = "View All"
    var didTap : (()->())?
    var body: some View {
        HStack {
            Text(title)
                .font(.customfont(.semibold, fontSize: 24))
                .foregroundColor(.primaryText)
            Spacer()
            Text(titleAll)
                .font(.customfont(.semibold, fontSize: 24))
                .foregroundColor(.primaryApp)
        }
    }
}

#Preview {
    SectionTitleAll()
}
