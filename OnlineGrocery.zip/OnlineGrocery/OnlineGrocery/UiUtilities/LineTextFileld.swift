//
//  LineTextFileld.swift
//  OnlineGrocery
//
//  Created by Amit Kumar on 5/14/24.
//

import SwiftUI

struct LineTextFileld: View {
    @State var title: String = "title"
    @State var placeholder: String = "Placeholder"
    @Binding var txt: String
    @State var keyboardType: UIKeyboardType = .default
    @State var isPassword: Bool = false
    var body: some View {
        VStack {
            Text(title)
                .font(.customfont(.semibold, fontSize: 16))
                .foregroundColor(.textTitle)
                .frame(minWidth: 0,maxWidth: .infinity,alignment:.leading)
                .padding(.bottom,4)
            if (isPassword) {
                SecureField(placeholder, text: $txt)
                    .frame(height: 40)
            } else {
                TextField(placeholder,text: $txt)
                    .keyboardType(keyboardType)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                    .frame(height: 40)
            }
            Divider()

            
        }
    }
}

struct LineSecureFileld: View {
    @State var title: String = "title"
    @State var placeholder: String = "Placeholder"
    @Binding var txt: String
    @Binding var isShowPassword: Bool

    @State var keyboardType: UIKeyboardType = .default
    var body: some View {
        VStack {
            Text(title)
                .font(.customfont(.semibold, fontSize: 16))
                .foregroundColor(.textTitle)
                .frame(minWidth: 0,maxWidth: .infinity,alignment:.leading)
                .padding(.bottom,4)
            if (isShowPassword) {
                TextField(placeholder, text: $txt)
                    .disableAutocorrection(true)
                    .keyboardType(keyboardType)
                    .autocapitalization(.none)
                    .modifier(ShowButton(isShow: $isShowPassword))
                    .frame(height: 40)
            } else {
                SecureField(placeholder, text: $txt)
                    .modifier(ShowButton(isShow: $isShowPassword))
                    .frame(height: 40)
            }

            Divider()

            
        }
    }
}


struct LineTextFileld_Previews: PreviewProvider {
    @State static var txt: String = ""
    static var previews: some View {
        LineTextFileld(txt: $txt)
            .padding(20)
    }
}
