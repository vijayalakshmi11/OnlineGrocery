//
//  Globs.swift
//  OnlineGrocery
//
//  Created by Amit Kumar on 5/15/24.
//

import SwiftUI

struct Globs {
    static let AppName = ""
    static let BASE_URL = "http://localhost:3001/api/app"
    static let SV_LOGIN = BASE_URL + "login"
    static let SV_SIGN_UP = BASE_URL + "sign_up"
    static let userPayload = "user_payload"
    static let userLogin = "user_login"

   
}
struct KKey {
    static let status = "status"
    static let message = "message"
    static let payload = "payload"
}

class Utils {
    class func UDSET(data: Any, key: String) {
        UserDefaults.standard.set(data, forKey: key)
        UserDefaults.standard.synchronize()
    }
    class func UDValue(key: String) -> Any {
        return UserDefaults.standard.value(forKey: key)as Any
    }
    class func UDValueBool(key: String) -> Bool {
        return UserDefaults.standard.value(forKey: key) as? Bool ?? true
    }
    class func UDValueTrueBool(key: String) -> Any {
        return UserDefaults.standard.value(forKey: key) as? Bool ?? true
    }
    class func UDRemove(key: String) -> Any {
        return UserDefaults.standard.removeObject(forKey: key)
        UserDefaults.standard.synchronize()
    }
    
}

