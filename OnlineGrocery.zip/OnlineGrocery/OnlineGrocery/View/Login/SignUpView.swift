//
//  SignUpView.swift
//  OnlineGrocery
//
//  Created by Amit Kumar on 5/15/24.
//

import SwiftUI

struct SignUpView: View {
    @Environment(\.presentationMode)var mode: Binding<PresentationMode>
    @StateObject var loginVM = LoginViewModel.shared
    var body: some View {
        ZStack {
            Image("bottom_bg")
                .resizable()
                .scaledToFill()
                .frame(width: .screenWidth, height: .screenHeight)
            ScrollView {
                VStack {
                    Image("color_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40)
                        .frame(width: .screenWidth * 0.1)
                    Text("Sign Up")
                        .font(.customfont(.semibold, fontSize: 26))
                        .foregroundColor(.primaryText)
                        .frame(minWidth: 0,maxWidth: .infinity,alignment: .leading)
                        .padding(.bottom,4)
                    
                    Text("Enter your credentials to continue")
                        .font(.customfont(.semibold, fontSize: 16))
                        .foregroundColor(.secondaryText)
                        .frame(minWidth: 0,maxWidth: .infinity,alignment: .leading)
                        .padding(.bottom,.screenWidth * 0.1)
                    
                    LineTextFileld( title: "Username", placeholder: "Enter your username",txt: $loginVM.txtUsername, keyboardType: .emailAddress)
                        .padding(.bottom,.screenWidth * 0.07)
                    
                    LineTextFileld( title: "Email", placeholder: "Enter your email address",txt: $loginVM.txtEmail, keyboardType: .emailAddress)
                        .padding(.bottom,.screenWidth * 0.07)
                    
                    LineSecureFileld(title: "Password", placeholder: "Enter your password",txt: $loginVM.txtPassWord, isShowPassword: $loginVM.isShowPassword)
                        .padding(.bottom,.screenWidth * 0.04)
                    VStack {
                        Text("By continuing you agree to our")
                            .font(.customfont(.semibold, fontSize: 14))
                            .foregroundColor(.secondaryText)
                            .frame(minWidth: 0,maxWidth: .infinity,alignment: .leading)
                        HStack {
                            Text("Terms of service")
                                .font(.customfont(.semibold, fontSize: 14))
                                .foregroundColor(.primaryApp)
                            Text("and")
                                .font(.customfont(.semibold, fontSize: 14))
                                .foregroundColor(.secondaryText)
                            Text("Privacy Policy")
                                .font(.customfont(.semibold, fontSize: 14))
                                .foregroundColor(.primaryApp)
                                .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                        }
                        .padding(.bottom,.screenWidth * 0.02)
                    }

                    RoundButton(title: "Sign Up") {
                        loginVM.serviceCallSignUp()
                    }
                    .padding(.bottom, .screenWidth * 0.03)
                    NavigationLink {
                        LoginView()
                    } label: {
                        HStack {
                            Text("Already have an account?")
                                .font(.customfont(.semibold, fontSize: 14))
                                .foregroundColor(.primaryText)
                            Text("Sign In")
                                .font(.customfont(.semibold, fontSize: 14))
                                .foregroundColor(.primaryApp)
                        }
                    }
                    Spacer()
                }
                .padding(.top,.topInsets + 64)
                .padding(.horizontal,20)
                .padding(.bottom,.bottomInsets)
            }
          
        }
        .alert(isPresented: $loginVM.showError, content: {
            Alert(title: Text(Globs.AppName), message: Text(loginVM.errorMessage), dismissButton: .default(Text("OK")))
        })
        .navigationTitle("")
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
        .ignoresSafeArea()
    }
}

#Preview {
    SignUpView()
}
